const YTDlpWrap = require('yt-dlp-wrap').default;
const path = require('path');
const fs = require('fs');
const os = require('os');

const isWindows = os.platform() === 'win32';
const binaryName = isWindows ? 'yt-dlp.exe' : 'yt-dlp';
const localBinaryPath = path.join(__dirname, '..', binaryName);

// Use local binary if it exists, otherwise assume it's in the PATH
const finalBinaryPath = fs.existsSync(localBinaryPath) ? localBinaryPath : 'yt-dlp';

const ytDlp = new YTDlpWrap(finalBinaryPath);

// Path to cookies file
const cookiesPath = path.join(__dirname, '..', 'cookies.txt');
const hasCookies = fs.existsSync(cookiesPath);

module.exports = { ytDlp, cookiesPath, hasCookies };
